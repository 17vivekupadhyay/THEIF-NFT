using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Solana.Unity.Wallet;
using Solana.Unity.Extensions;
using Solana.Unity.Rpc.Types;

public class Blockchain : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void ConnectWallet()
    {
        // Use Solana Unity SDK to connect to wallet
        
    }

}
