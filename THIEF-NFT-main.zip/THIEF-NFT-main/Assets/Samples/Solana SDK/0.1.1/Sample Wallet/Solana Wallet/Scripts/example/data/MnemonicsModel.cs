using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Solana.Unity.SDK.Example
{
    public class MnemonicsModel
    {
        public List<string> Mnemonics { get; set; }
    }
}